//
//  SiloView.h
//  SiloView
//
//  Created by Jose Quintero on 1/1/16.
//  Copyright © 2016 Quintero. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SiloView.
FOUNDATION_EXPORT double SiloViewVersionNumber;

//! Project version string for SiloView.
FOUNDATION_EXPORT const unsigned char SiloViewVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SiloView/PublicHeader.h>


